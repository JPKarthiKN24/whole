
public interface Bike {

      void breaking();
     
      void getMillage();
     
      void getCc();

}
