
public class YamazaR15 implements Bike {

	
	public void breaking() {
		String bs="manual single disc";
		System.out.println("Breaking system : "+bs);
		
	}
	public void getMillage() {
		int mil=40;
		System.out.println("Milage : "+mil);
		
	}
	public void getCc() {
	int c=150;
	System.out.println("CC : "+c);
		
	}
	public void getComfort(){
		
		System.out.println("r15 is more comfortable than any other bikes for me");
	}
    
}
