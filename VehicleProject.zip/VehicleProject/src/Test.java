
public class Test implements Bike {

	@Override
	public void breaking() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getMillage() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getCc() {
		// TODO Auto-generated method stub
		
	}

}
